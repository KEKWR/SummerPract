from email.headerregistry import ContentDispositionHeader
import re
from django.http import Http404, HttpRequest, HttpResponse, HttpResponseNotFound
from django.shortcuts import get_object_or_404, render
from .models import *


def main(request):
    return render(request,'main/main.html', {'title': 'Советское кино'})

def actor(request):
    post = Actor.objects.all()
    cats = Category.objects.all()

    context = {
        'post':post,
        'cats':cats,
        'title': 'Актеры',
        'cats_selected':0,
    }

    return render(request, 'main/actor.html', context=context)

def movies(request):
    stsop = Movie.objects.all()
    kats = Kategorii.objects.all()
    context = {
        'title': 'Фильмы',
        'kats':kats,
        'stsop':stsop,
        'kat_sel':0,
    }
    return  render(request, 'main/movies.html', context=context)

def reviews(request):
    return  render(request, 'main/reviews.html', {'title': 'Рецензии'})

def history(request):
    return  render(request, 'main/history.html', {'title': 'Исторяи кино'})

def account(request):
    return  render(request, 'main/account.html', {'title': 'Вход/Регистрация'})

def show_actor(request,post_slug):
    post = get_object_or_404(Actor,slug=post_slug)

    context = {
        'post':post,
        'title':post.title,
        'cat_selected': post.cat_id,
    }

    return render(request,'main/actpost.html',context=context)

def show_category(request,cat_id):
    post = Actor.objects.filter(cat_id=cat_id)
    cats = Category.objects.all()

    context = {
        'post':post,
        'cats':cats,
        'title': 'Люди',
        'cats_selected':cat_id,
    }
    
    return render(request, 'main/actor.html', context=context)


def show_mov(request,tsop_id):
    tsop = get_object_or_404(Movie,pk=tsop_id)
    context = {
        'tsop':tsop,
        'title':tsop.title,
        'kat_sel': tsop.kat_id,
    }
    return render(request,'main/moviepost.html',context=context)

def show_kat(request,kat_id):
    stsop = Movie.objects.filter(kat_id=kat_id)
    kats = Kategorii.objects.all()


    context = {
        'stsop':stsop,
        'kats' :kats,
        'kat_sel': kat_id,
        'title':'Фильмы'
    }
    return render(request,'main/movies.html',context=context)
from django.urls import path
from .views import *
urlpatterns = [
    path('',main,name='home'),
    path('actor/',actor,name='actor'),
    path('movies/',movies,name='movies'),
    path('reviews/',reviews,name='reviews'),
    path('history/',history,name='history'),
    path('account/',account,name ='account'),
    path('actor/<slug:post_slug>/',show_actor ,name='post'),
    path('category/<int:cat_id>/',show_category ,name='category'),

    path('movies/<int:tsop_id>',show_mov, name='tsop'),
    path('kategorii/<int:kat_id>', show_kat, name='kategorii')
]
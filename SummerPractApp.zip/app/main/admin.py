from django.contrib import admin
from .models import *

class ActorAdmin(admin.ModelAdmin):
    prepopulated_fields = {"slug":("title",)}

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id','name')
    list_display_links = ('id','name')
    search_fields = ('name',)
    prepopulated_fields = {"slug":("name",)}

class KategoryAdmin(admin.ModelAdmin):
    list_display = ('id','name')
    list_display_links = ('id','name')
    search_fields = ('name',)

admin.site.register(Actor,ActorAdmin)
admin.site.register(Category,CategoryAdmin)

admin.site.register(Movie)
admin.site.register(Kategorii,KategoryAdmin)

